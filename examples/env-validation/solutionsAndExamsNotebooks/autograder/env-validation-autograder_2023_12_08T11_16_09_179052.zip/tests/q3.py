OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert len(stats) == 1000\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert 0 <= p_value <= 1\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> import math\n>>> assert math.isclose(observed, 0.45037490465339625)\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> import math\n>>> assert math.isclose(p_value, 0.003)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
