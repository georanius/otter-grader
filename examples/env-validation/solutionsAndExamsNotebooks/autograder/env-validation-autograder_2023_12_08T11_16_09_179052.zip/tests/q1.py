OK_FORMAT = True

test = {   'name': 'q1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert hailstone(1) == [1]\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert hailstone(2) == [2, 1]\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert hailstone(3) == [3, 10, 5, 16, 8, 4, 2, 1]\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert hailstone(7) == [7, 22, 11, 34, 17, 52, 26, 13, 40, 20, 10, 5, 16, 8, 4, 2, 1]\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
