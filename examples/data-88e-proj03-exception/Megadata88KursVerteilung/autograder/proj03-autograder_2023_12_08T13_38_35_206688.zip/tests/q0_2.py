from otter.test_files import test_case

OK_FORMAT = False

name = "q0_2"
points = None

@test_case(points=None, hidden=False)
def test_q0_2(defaults):
    assert "education" not in defaults.columns
    assert "marital_status" not in defaults.columns
    assert "sex_male" in defaults.columns

