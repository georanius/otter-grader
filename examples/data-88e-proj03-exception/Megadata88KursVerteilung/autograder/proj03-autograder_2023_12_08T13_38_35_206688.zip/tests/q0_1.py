from otter.test_files import test_case

OK_FORMAT = False

name = "q0_1"
points = None

@test_case(points=None, hidden=False)
def test_q0_1(q0_1):
    assert len(q0_1) in [3, 4]
    assert "sex" in q0_1
    assert "education" in q0_1
    assert "marital_status" in q0_1

