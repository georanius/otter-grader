from otter.test_files import test_case

OK_FORMAT = False

name = "q1_2"
points = None

@test_case(points=None, hidden=False)
def test_q1_2_1(np, slope):
    np.random.seed(1234)
    x2 = np.random.uniform(0, 10, 5)
    y2 = np.random.uniform(0, 10, 5)
    assert np.isclose(slope(x2, y2), 0.853965497371089)

@test_case(points=None, hidden=False)
def test_q1_2_2(np, intercept):
    np.random.seed(1234)
    x2 = np.random.uniform(0, 10, 5)
    y2 = np.random.uniform(0, 10, 5)
    assert np.isclose(intercept(x2, y2), 1.5592892975597108)

@test_case(points=0.5, hidden=True)
def test_q1_2_3(np, slope):
    np.random.seed(2345)
    x2 = np.random.uniform(0, 10, 5)
    y2 = np.random.uniform(0, 10, 5)
    assert np.isclose(slope(x2, y2), -0.5183482739336265)

@test_case(points=0.5, hidden=True)
def test_q1_2_4(np, intercept):
    np.random.seed(2345)
    x2 = np.random.uniform(0, 10, 5)
    y2 = np.random.uniform(0, 10, 5)
    assert np.isclose(intercept(x2, y2), 7.777051922080558)

