from otter.test_files import test_case

OK_FORMAT = False

name = "q1_1"
points = None

@test_case(points=None, hidden=False)
def test_q1_1_1(np, corr):
    np.random.seed(1234)
    x2 = np.random.uniform(0, 10, 5)
    y2 = np.random.uniform(0, 10, 5)
    assert np.isclose(corr(x2, y2), 0.6410799722591175)

@test_case(points=1, hidden=True)
def test_q1_1_2(np, corr):
    np.random.seed(2345)
    x2 = np.random.uniform(0, 10, 5)
    y2 = np.random.uniform(0, 10, 5)
    assert np.isclose(corr(x2, y2), -0.4008555019904271)

